<?php
    require_once ("controleur/config_db.php"); 
    require_once ("controleur/controleur.class.php"); 
    //instancier la classe controleur 
    $unControleur = new Controleur($serveur, $bdd, $user, $mdp);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Page de Connexion</title>
</head>
<body>
    <div class="logo">
        <img src="logo.png" alt="">
    </div>
    <div class="page">
        <form action="" method="post">
            <input class="taille" type="text" name="email" placeholder="identifiant" required><br><br>
            <input class="taille" type="password" name="mdp" placeholder="Mot de passe" required><br><br>
            <div class="one">
                <input type="checkbox" id="rester-connecter" name="rester-connecter" checked>
                <label for="rester-connecter">Rester <br>connecter</label><br><br>
            </div>
            <input type="submit" name="seConnecter"  value="Se connecter">
            <a class="mdp-forget" href="#">Mot de passe oublié ?</a>
        </form>

        <br><br>
        
        
    </div>  
    <?php
    if(isset($_POST['seConnecter']))
    {
        $email = $_POST['email']; 
        $mdp = $_POST['mdp']; 
        $where = array("email"=>$email, "mdp"=>$mdp); 
        $chaine ="*"; 
        $unControleur->setTable ("Utilisateur"); 
        $unUser = $unControleur->selectWhere($chaine,$where); 
        if (isset($unUser['email'])){
            echo "Bonjour : ".$unUser['nom']."  ".$unUser['prenom'];
        }else {
            echo "Erreur, Veuillez vérifier vos identifiants";
        }
    }
    ?>
    
</body>
</html>