drop database if exists reseausocial;
create database reseausocial;
use reseausocial;

#------------------------------------------------------------
#        Script MySQL.
#------------------------------------------------------------


#------------------------------------------------------------
# Table: Utilisateur
#------------------------------------------------------------

CREATE TABLE Utilisateur(
        idutilisateur    Int  Auto_increment  NOT NULL ,
        nom              Varchar (50) NOT NULL ,
        prenom           Varchar (50) NOT NULL ,
        pseudo           Varchar (50) NOT NULL ,
        date_naiss       Date NOT NULL ,
        email            Varchar (50) NOT NULL ,
        date_inscription Date NOT NULL ,
        mdp              Varchar (50) NOT NULL
	,CONSTRAINT Utilisateur_PK PRIMARY KEY (idutilisateur)
)ENGINE=InnoDB;

#------------------------------------------------------------
# Table: DemandeAmis
#------------------------------------------------------------

CREATE TABLE DemandeAmis(
        iddemande              Int  Auto_increment  NOT NULL ,
        date_invit             Date NOT NULL ,
        date_confirmation      Date ,
        statut                 Bool NOT NULL ,
        idutilisateur          Int NOT NULL ,
        idutilisateur_Recevoir Int NOT NULL ,
		idutilisateur_Faire Int NOT NULL

	,CONSTRAINT DemandeAmis_PK PRIMARY KEY (iddemande)

	,CONSTRAINT DemandeAmis_Utilisateur_FK FOREIGN KEY (idutilisateur_Recevoir) REFERENCES Utilisateur(idutilisateur)
	,CONSTRAINT DemandeAmis_Utilisateur_2_FK FOREIGN KEY (idutilisateur_Faire) REFERENCES Utilisateur(idutilisateur)
)ENGINE=InnoDB;



#------------------------------------------------------------
# Table: Lieu
#------------------------------------------------------------

CREATE TABLE Lieu(
        idlieu  Int  Auto_increment  NOT NULL ,
        adresse     Varchar (50) NOT NULL ,
        departement Varchar (50) NOT NULL ,
        ville       Varchar (50) NOT NULL ,
		codepostal  CHAR (5) NOT NULL
	,CONSTRAINT Lieu_PK PRIMARY KEY (idlieu)
)ENGINE=InnoDB;

#------------------------------------------------------------
# Table: Images
#------------------------------------------------------------

CREATE TABLE Images(
        idimage     Int  Auto_increment  NOT NULL ,
        type        Varchar (50) NOT NULL ,
        url         LONGTEXT NOT NULL 
	,CONSTRAINT Images_PK PRIMARY KEY (idimage)

)ENGINE=InnoDB;

#------------------------------------------------------------
# Table: Evenement
#------------------------------------------------------------

CREATE TABLE Evenement(
        idevenement   Int  Auto_increment  NOT NULL ,
        nom           Varchar (50) NOT NULL ,
        date_debut    Date NOT NULL ,
        heure_debut   Time NOT NULL ,
        description   LONGTEXT NOT NULL ,
        organisateur  Varchar (50) NOT NULL ,
        date_fin      Date NOT NULL ,
        heure_fin     Time NOT NULL ,
        idutilisateur Int NOT NULL ,
        idlieu   Int NOT NULL ,
		idimage Int NOT NULL
	,CONSTRAINT Evenement_PK PRIMARY KEY (idevenement)

	,CONSTRAINT Evenement_Utilisateur_FK FOREIGN KEY (idutilisateur) REFERENCES Utilisateur(idutilisateur)
	,CONSTRAINT Evenement_Lieu_FK FOREIGN KEY (idlieu) REFERENCES Lieu(idlieu)
	,CONSTRAINT Evenement_Images_FK FOREIGN KEY (idimage) REFERENCES Images(idimage)
)ENGINE=InnoDB;





#------------------------------------------------------------
# Table: Avoir
#------------------------------------------------------------

CREATE TABLE Avoir(
	idevenement Int NOT NULL ,
	idimage Int NOT NULL
	  ,CONSTRAINT Avoir_PK PRIMARY KEY (idevenement,idimage)

	  ,CONSTRAINT Avoir_Evenement_FK FOREIGN KEY (idevenement) REFERENCES Evenement(idevenement)
	  ,CONSTRAINT Avoir_Images_FK FOREIGN KEY (idimage) REFERENCES Images(idimage)
	 
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Post
#------------------------------------------------------------

CREATE TABLE Post(
        idpost        Int  Auto_increment  NOT NULL ,
        date_post     Datetime NOT NULL ,
        type_post     Varchar (50) NOT NULL ,
        contenu       Varchar (100) NOT NULL ,
        idutilisateur_Publier Int NOT NULL ,
        idimage_Contient       Int NULL
	,CONSTRAINT Post_PK PRIMARY KEY (idpost)

	,CONSTRAINT Post_Utilisateur_FK FOREIGN KEY (idutilisateur_Publier) REFERENCES Utilisateur(idutilisateur)
	,CONSTRAINT Post_Images_FK FOREIGN KEY (idimage_Contient) REFERENCES Images(idimage)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: CommenterPost
#------------------------------------------------------------

CREATE TABLE CommenterPost(
        idpost        Int NOT NULL ,
        idutilisateur Int NOT NULL ,
        contenu       LONGTEXT NOT NULL
	,CONSTRAINT CommenterPost_PK PRIMARY KEY (idpost,idutilisateur)

	,CONSTRAINT CommenterPost_Post_FK FOREIGN KEY (idpost) REFERENCES Post(idpost)
	,CONSTRAINT CommenterPost_Utilisateur_FK FOREIGN KEY (idutilisateur) REFERENCES Utilisateur(idutilisateur)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Publier
#------------------------------------------------------------

CREATE TABLE Publier(
	idutilisateur Int NOT NULL ,
	idpost Int NOT NULL
	  ,CONSTRAINT Publier_PK PRIMARY KEY (idutilisateur,idpost)

	  ,CONSTRAINT Publier_Utilisateur_FK FOREIGN KEY (idutilisateur) REFERENCES Utilisateur(idutilisateur)
	  ,CONSTRAINT Publier_Post_FK FOREIGN KEY (idpost) REFERENCES Post(idpost)
	 
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Recevoir
#------------------------------------------------------------

CREATE TABLE Recevoir(
	idutilisateur Int NOT NULL ,
	iddemande Int NOT NULL
	  ,CONSTRAINT Recevoir_PK PRIMARY KEY (idutilisateur,iddemande)

	  ,CONSTRAINT Recevoir_Utilisateur_FK FOREIGN KEY (idutilisateur) REFERENCES Utilisateur(idutilisateur)
	  ,CONSTRAINT Recevoir_DemandeAmis_FK FOREIGN KEY (iddemande) REFERENCES DemandeAmis(iddemande)
	 
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Faire
#------------------------------------------------------------

CREATE TABLE Faire(
	idutilisateur Int NOT NULL ,
	iddemande Int NOT NULL
	  ,CONSTRAINT Faire_PK PRIMARY KEY (idutilisateur,iddemande)

	  ,CONSTRAINT Faire_Utilisateur_FK FOREIGN KEY (idutilisateur) REFERENCES Utilisateur(idutilisateur)
	  ,CONSTRAINT Faire_DemandeAmis_FK FOREIGN KEY (iddemande) REFERENCES DemandeAmis(iddemande)
	 
)ENGINE=InnoDB;

#------------------------------------------------------------
# Table: Messages
#------------------------------------------------------------

CREATE TABLE Messages(
        idmessage              Int  Auto_increment  NOT NULL ,
        contenu                Varchar (50) NOT NULL ,
        date_envoi             Datetime NOT NULL ,
        idutilisateur_RecevoirMessage Int NOT NULL ,
		idutilisateur_Envoyer Int NOT NULL
	,CONSTRAINT Messages_PK PRIMARY KEY (idmessage)

	,CONSTRAINT Messages_Utilisateur_2_FK FOREIGN KEY (idutilisateur_RecevoirMessage) REFERENCES Utilisateur(idutilisateur)
	,CONSTRAINT Messages_Utilisateur_3_FK FOREIGN KEY (idutilisateur_Envoyer) REFERENCES Utilisateur(idutilisateur)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Groupe
#------------------------------------------------------------

CREATE TABLE Groupe(
        idgroupe        Int  Auto_increment  NOT NULL ,
        nom_groupe      Varchar (50) NOT NULL ,
        nb_participants Int NOT NULL ,
        date_creation   Datetime NOT NULL ,
		idutilisateur_Creer   Int NOT NULL
	,CONSTRAINT Groupe_PK PRIMARY KEY (idgroupe)

	,CONSTRAINT Groupe_Utilisateur_2_FK FOREIGN KEY (idutilisateur_Creer) REFERENCES Utilisateur(idutilisateur)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Commenter
#------------------------------------------------------------

CREATE TABLE Commenter(
        idevenement   Int NOT NULL ,
        idutilisateur Int NOT NULL ,
        note          Int NOT NULL ,
        contenu       LONGTEXT NOT NULL
	,CONSTRAINT Commenter_PK PRIMARY KEY (idevenement,idutilisateur)

	,CONSTRAINT Commenter_Evenement_FK FOREIGN KEY (idevenement) REFERENCES Evenement(idevenement)
	,CONSTRAINT Commenter_Utilisateur_FK FOREIGN KEY (idutilisateur) REFERENCES Utilisateur(idutilisateur)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Participer
#------------------------------------------------------------

CREATE TABLE Participer(
        idevenement   Int NOT NULL ,
        idutilisateur Int NOT NULL ,
        dateinscrit   Datetime NOT NULL
	,CONSTRAINT Participer_PK PRIMARY KEY (idevenement,idutilisateur)

	,CONSTRAINT Participer_Evenement_FK FOREIGN KEY (idevenement) REFERENCES Evenement(idevenement)
	,CONSTRAINT Participer_Utilisateur_FK FOREIGN KEY (idutilisateur) REFERENCES Utilisateur(idutilisateur)
)ENGINE=InnoDB;



#------------------------------------------------------------
# Table: Creer
#------------------------------------------------------------

CREATE TABLE Creer(
	idutilisateur Int NOT NULL ,
	idgroupe Int NOT NULL
	  ,CONSTRAINT Creer_PK PRIMARY KEY (idutilisateur,idgroupe)

	  ,CONSTRAINT Creer_Utilisateur_FK FOREIGN KEY (idutilisateur) REFERENCES Utilisateur(idutilisateur)
	  ,CONSTRAINT Creer_Groupe0_FK FOREIGN KEY (idgroupe) REFERENCES Groupe(idgroupe)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Se derouler
#------------------------------------------------------------

CREATE TABLE Sederouler(
	idlieu Int NOT NULL ,
	idevenement Int NOT NULL
	  ,CONSTRAINT Sederouler_PK PRIMARY KEY (idlieu,idevenement)
	  ,CONSTRAINT Sederouler_Evenement_FK FOREIGN KEY (idevenement) REFERENCES Evenement(idevenement)
	  ,CONSTRAINT Sederouler_Lieu_FK FOREIGN KEY (idlieu) REFERENCES Lieu(idlieu)
)ENGINE=InnoDB;

#------------------------------------------------------------
# Table: Constituer
#------------------------------------------------------------

CREATE TABLE Constituer(
	idutilisateur Int NOT NULL ,
	idgroupe Int NOT NULL
	  ,CONSTRAINT Constituer_PK PRIMARY KEY (idutilisateur,idgroupe)
	  ,CONSTRAINT Constituer_Groupe_FK FOREIGN KEY (idgroupe) REFERENCES Groupe(idgroupe)
	  ,CONSTRAINT Constituer_Utilisateur_FK FOREIGN KEY (idutilisateur) REFERENCES Utilisateur(idutilisateur)
)ENGINE=InnoDB;

#------------------------------------------------------------
# Table: Organiser
#------------------------------------------------------------

CREATE TABLE Organiser(
	idutilisateur Int NOT NULL ,
	idevenement Int NOT NULL
	  ,CONSTRAINT Organiser_PK PRIMARY KEY (idutilisateur,idevenement)

	  ,CONSTRAINT Organiser_Utilisateur_FK FOREIGN KEY (idutilisateur) REFERENCES Utilisateur(idutilisateur)
	  ,CONSTRAINT Organiser_Evenement_FK FOREIGN KEY (idevenement) REFERENCES Evenement(idevenement)
	 
)ENGINE=InnoDB;




#------------------------------------------------------------
# Table: Contient
#------------------------------------------------------------

CREATE TABLE Contient(
	idpost Int NOT NULL ,
	idimage Int NOT NULL
	  ,CONSTRAINT Contient_PK PRIMARY KEY (idpost,idimage)

	  ,CONSTRAINT Contient_Post_FK FOREIGN KEY (idpost) REFERENCES Post(idpost)
	  ,CONSTRAINT Contient_Images_FK FOREIGN KEY (idimage) REFERENCES Images(idimage)
	 
)ENGINE=InnoDB;



#------------------------------------------------------------
# Table: RecevoirMessage
#------------------------------------------------------------

CREATE TABLE RecevoirMessage(
	idutilisateur Int NOT NULL ,
	idmessage Int NOT NULL
	  ,CONSTRAINT RecevoirMessage_PK PRIMARY KEY (idutilisateur,idmessage)

	  ,CONSTRAINT RecevoirMessage_Utilisateur_FK FOREIGN KEY (idutilisateur) REFERENCES Utilisateur(idutilisateur)
	  ,CONSTRAINT RecevoirMessage_Messages_FK FOREIGN KEY (idmessage) REFERENCES Messages(idmessage)
	 
)ENGINE=InnoDB;
	
#------------------------------------------------------------
# Table: Envoyer
#------------------------------------------------------------

CREATE TABLE Envoyer(
	idutilisateur Int NOT NULL ,
	idmessage Int NOT NULL
	  ,CONSTRAINT Envoyer_PK PRIMARY KEY (idutilisateur,idmessage)

	  ,CONSTRAINT Envoyer_Utilisateur_FK FOREIGN KEY (idutilisateur) REFERENCES Utilisateur(idutilisateur)
	  ,CONSTRAINT Envoyer_Messages_FK FOREIGN KEY (idmessage) REFERENCES Messages(idmessage)
	 
)ENGINE=InnoDB;